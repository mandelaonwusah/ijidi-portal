IJIDI brand pictures (circle-cropped, transparent outside the gold frame)

UPLOAD (GitHub web editor):
  1. Open the repo, go to the public folder, open (or create) the folder named brand.
  2. Click Add file > Upload files and drag in every file from the brand folder of this zip.
  3. Commit. The portal reads them from /brand/...

Files:
  ijidi-group / ijidi-foundation / ijidi-atelier   the three entity logos
  ijidi-wild / -toons / -arena / -stage / -restore / -sound   IJIDI Media property logos
  mandela / ifeoma   the two portraits (assigned by first name: swap the file names if I got them the wrong way round)
  ijidi-fan-emblem.webp   the fan emblem, trimmed to the artwork
  igx-core.jpg   the IGX AI core (needed by the IGX AI orb)

No IJIDI Orbit logo was supplied, so it has no file yet.
